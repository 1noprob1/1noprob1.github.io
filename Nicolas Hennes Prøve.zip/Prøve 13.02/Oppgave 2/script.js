async function hentData() {
    let response = await fetch('https://www.anapioficeandfire.com/api/books');
    let data = await response.json();

    for (let i = 0; i < data.length; i++) {
        let boknavn = document.createElement("p");
        boknavn.innerText = data[i].name;
        document.querySelector("#bok").appendChild(boknavn);

        let utgivelsesdato = document.createElement("p");
        utgivelsesdato.innerText = data[i].released;
        document.querySelector("#bok").appendChild(utgivelsesdato);

        let sideantall = document.createElement("p");
        sideantall.innerText = data[i].numberOfPages;
        document.querySelector("#bok").appendChild(sideantall);

    }
}

hentData();